# FluentMe AI — Smart Learning Studio (v2.0)

**Your personal mobile English learning companion, with up to 60 minutes per day.**

## Added in this version

- Flexible learning goals **15, 30, 35, 40, 45 or 60 minutes**, with a daily practice-time recording cap of 60 minutes. Different tasks adjust to your chosen goal. Taking a short day or a rest day is fine.
- **Adaptive starting point:** a 10-item grammar placement quiz recommends A1/A2/B1/B2. This is a very short informal grammar check, **not** a certified CEFR assessment or reliable test of spoken fluency.
- **Guided conversation simulator:** practice daily life, university, interviews and career conversations using voice or text; scripted follow-up prompts are not generative AI.
- **Personal mistake notebook:** save limited rule-based corrections, reveal and review them, and keep a review history.
- **Pronunciation practice studio:** use speech-to-text to see the words recognized, then compare with a target sentence. Word overlap **is not pronunciation or accent scoring**.
- **Spaced vocabulary revision:** word review scheduling with self-assessed recall and Sinhala explanations.
- **Skill metrics:** counts actual grammar attempts, correct answers, speaking attempts and completed career practice. No fabricated fluency percentile.
- **Motivation coach and daily reminders:** supportive messages, short missions, optional reminders and milestones with no streak pressure.
- **Career English lab:** accounting, finance, presentations, workplace meetings and interviews.
- **Daily history, backup/import, progress statistics**, and offline guided mode.

## What remains optional

The app does **not** have a live generative AI teacher pre-connected. An **eligible account owner** may separately deploy and maintain the optional Cloudflare Worker in `cloudflare-worker/` and connect its HTTPS URL. No API keys or paid credits are included. Third-party terms, age requirements, quotas and any fees remain applicable. There is no promise of unlimited free AI. Speech recognition and Android speech services may need internet or compatible phone support.

## Downloads / use

- **Single HTML file**: `FluentMe_AI_Smart_Coach.html` (in the downloadable outputs) opens in Chrome or another compatible browser. A downloaded file does not become an installed APK, and local-file browser restrictions can limit microphone and notifications.
- **Android source project**: open the `android/` folder using a recent Android Studio + Android SDK 35. Sync the Gradle project, select **Build > Build Bundle(s) / APK(s) > Build APK(s)**. The usual output is `app/build/outputs/apk/debug/app-debug.apk`.
- **Web PWA**: host `web/` on HTTPS if you want browser installation features. Offline app shell caches when visited via HTTPS.

Android reminders use local notification schedules, with permission and possible battery-delivery delays; web reminders only work when the page remains open.

The source project and web app have been tested at the browser UI level. **No Android APK has been compiled or phone-tested here**: Android SDK / Gradle build tools are unavailable in this environment.

## Privacy and learning records

Learning progress stays in your local browser/app storage; export backups from Settings. Clearing storage or switching app environments can remove progress unless backed up and restored. Online AI mode sends recent practice messages to your chosen backend and AI provider; do not share private personal information.

FluentMe is an independent educational project, not affiliated with ELSA Speak.
