package com.fluentme.coach;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public final class ReminderBootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context,Intent intent) {
        if(Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction()) || Intent.ACTION_TIMEZONE_CHANGED.equals(intent.getAction()))
            PracticeAlarm.restore(context);
    }
}
